import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Eraser, c as Check, i as Pilcrow, l as CaseSensitive, o as Copy, r as Space, s as Clock, t as WholeWord, u as AlignLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CoWfzfcR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var READING_WPM = 200;
function analyze(text) {
	const characters = [...text].length;
	const charactersNoSpaces = [...text.replace(/\s/g, "")].length;
	const trimmed = text.trim();
	const words = trimmed ? trimmed.split(/\s+/).filter((token) => /[\p{L}\p{N}]/u.test(token)).length : 0;
	const paragraphs = trimmed ? text.split(/\n+/).filter((block) => /[\p{L}\p{N}]/u.test(block)).length : 0;
	const sentences = trimmed ? trimmed.replace(/\s+/g, " ").split(/[.!?…]+/u).filter((chunk) => /[\p{L}\p{N}]/u.test(chunk)).length : 0;
	let readingValue = "0";
	if (words > 0) {
		const minutes = words / READING_WPM;
		readingValue = minutes < 1 ? "< 1" : String(Math.round(minutes));
	}
	return {
		words,
		characters,
		charactersNoSpaces,
		sentences,
		paragraphs,
		readingValue
	};
}
function formatCount(value) {
	return new Intl.NumberFormat("en-US").format(value);
}
function Home() {
	const [text, setText] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const resetCopy = (0, import_react.useRef)(null);
	const stats = (0, import_react.useMemo)(() => analyze(text), [text]);
	const empty = text.length === 0;
	(0, import_react.useEffect)(() => {
		return () => {
			if (resetCopy.current !== null) window.clearTimeout(resetCopy.current);
		};
	}, []);
	const cards = [
		{
			label: "Words",
			value: formatCount(stats.words),
			detail: "in this text",
			icon: WholeWord,
			emphasis: true
		},
		{
			label: "Characters",
			value: formatCount(stats.characters),
			detail: "with spaces",
			icon: CaseSensitive
		},
		{
			label: "Characters",
			value: formatCount(stats.charactersNoSpaces),
			detail: "without spaces",
			icon: Space
		},
		{
			label: "Sentences",
			value: formatCount(stats.sentences),
			detail: "split on . ! ?",
			icon: Pilcrow
		},
		{
			label: "Paragraphs",
			value: formatCount(stats.paragraphs),
			detail: "split on new lines",
			icon: AlignLeft
		},
		{
			label: "Reading time",
			value: stats.readingValue,
			detail: "min · 200 wpm",
			icon: Clock
		}
	];
	function markCopied() {
		setCopied(true);
		if (resetCopy.current !== null) window.clearTimeout(resetCopy.current);
		resetCopy.current = window.setTimeout(() => setCopied(false), 1800);
	}
	async function copyText() {
		if (!text) return;
		try {
			await navigator.clipboard.writeText(text);
			markCopied();
			return;
		} catch {
			const field = document.getElementById("draft");
			if (!(field instanceof HTMLTextAreaElement)) return;
			field.focus();
			field.select();
			if (document.execCommand("copy")) markCopied();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto w-full max-w-5xl flex-1 px-4 pt-8 pb-6 sm:px-6 sm:pt-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/avatar.png",
						alt: "",
						width: 512,
						height: 512,
						className: "size-14 shrink-0 drop-shadow-md sm:size-16"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-tight font-medium tracking-tight text-fg sm:text-5xl",
							children: "Free Word Counter"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
							children: "Count words, characters, sentences & more instantly"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					"aria-label": "Text statistics",
					className: "mt-8 grid grid-cols-2 gap-3 sm:mt-10 sm:grid-cols-3 lg:grid-cols-6",
					children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "panel min-w-0 rounded-2xl px-3.5 py-3.5 sm:px-4 sm:py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.icon, {
									className: "size-4 shrink-0",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "truncate text-sm font-semibold",
									children: card.label
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `stat-value mt-2 text-3xl font-semibold sm:text-4xl ${card.emphasis ? "text-primary" : "text-fg"}`,
								children: card.value
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 truncate text-sm text-muted",
								children: card.detail
							})
						]
					}, `${card.label}-${card.detail}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "editor-shell mt-4 rounded-2xl sm:mt-5",
					"aria-label": "Text editor",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "draft",
							className: "sr-only",
							children: "Text to analyze"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "draft",
							value: text,
							onChange: (event) => {
								setText(event.target.value);
								setCopied(false);
							},
							placeholder: "Paste or start typing your text here…",
							spellCheck: true,
							className: "block min-h-64 w-full resize-y bg-transparent px-4 py-4 text-lg leading-relaxed text-fg outline-none placeholder:text-muted sm:min-h-80 sm:px-5 sm:py-5 lg:min-h-96"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-end gap-2 border-t border-line px-3 py-3 sm:px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setText("");
									setCopied(false);
									document.getElementById("draft")?.focus();
								},
								disabled: empty,
								className: "inline-flex h-11 items-center gap-2 rounded-xl px-4 text-sm font-semibold text-muted transition-colors duration-200 hover:bg-wash hover:text-fg disabled:cursor-not-allowed disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Clear"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									copyText();
								},
								disabled: empty,
								className: "inline-flex h-11 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-on-primary transition-colors duration-200 hover:bg-primary-strong disabled:cursor-not-allowed disabled:opacity-40",
								children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
									className: "size-4",
									"aria-hidden": "true"
								}), copied ? "Copied" : "Copy"]
							})]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "px-4 py-6 text-center text-sm text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Free forever • No signup required" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1",
				children: "Your text stays in this browser. Nothing is uploaded."
			})]
		})]
	});
}
//#endregion
export { Home as component };
