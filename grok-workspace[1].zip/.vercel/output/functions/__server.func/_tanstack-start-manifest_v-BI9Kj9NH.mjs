//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BI9Kj9NH.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CMMADX4R.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CMMADX4R.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Z4pCD2nw.js"]
	}
} });
//#endregion
export { tsrStartManifest };
